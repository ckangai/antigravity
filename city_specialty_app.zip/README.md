# CitySpecialty Application

A Flask application running on Google Cloud Run with Cloud SQL.

## Deployment
See [DEPLOY_INSTRUCTIONS.md](DEPLOY_INSTRUCTIONS.md) for detailed deployment steps.

## Local Development
1. Install dependencies: `pip install -r requirements.txt`
2. Run app: `python app.py`
